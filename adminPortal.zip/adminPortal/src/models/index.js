// index.js
const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASS, {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 3306,
    dialect: 'mysql',
    logging: false,
});

// Import models
const Products = require('./products')(sequelize, Sequelize);
const ProductCategory = require('./productCategory')(sequelize, Sequelize);
const Users = require('./users')(sequelize, Sequelize);

// Database connection and sync
const Connection = async () => {
    try {
        await sequelize.authenticate();
        console.log('MySQL connected');

        await sequelize.sync()
            .then(() => {
                console.log('Models synchronized');
            })
            .catch((err) => {
                console.error('Error syncing models:', err);
            });

    } catch (error) {
        console.error('MySQL database connection error:', error);
    }
};

// Establish relationships
Products.belongsTo(ProductCategory, { foreignKey: 'categoryId', targetKey: 'id' });
ProductCategory.hasMany(Products, { foreignKey: 'categoryId' });

module.exports = { Connection, Products, ProductCategory, Users };