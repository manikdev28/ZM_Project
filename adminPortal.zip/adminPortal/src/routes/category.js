const express = require('express');
const router = express.Router();
const categoryController = require('../controllers/categoryController');
const { isAuthenticated } = require('../../utilis/auth');

router.get('/', isAuthenticated, categoryController.GetAllCategories);
router.get('/add-view', isAuthenticated, categoryController.AddCategoryView);
router.post('/add', isAuthenticated, categoryController.AddCategory);
router.get('/edit-view/:id', isAuthenticated, categoryController.EditCategoryView);
router.post('/edit/:id', isAuthenticated, categoryController.EditCategory);
router.get('/delete/:id', isAuthenticated, categoryController.DeleteCategory);

module.exports = router;