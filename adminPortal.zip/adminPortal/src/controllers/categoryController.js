const { ProductCategory } = require('../models');

const GetAllCategories = async (req, res) => {
  const categories = await ProductCategory.findAll({ raw: true });
  res.render('categories/Categories', { AllCategories: categories });
};

const AddCategoryView = async (req, res) => {
  res.render('categories/AddCategory');
};

const AddCategory = async (req, res) => {
  const CategoryName = req.body.CategoryName;

  await ProductCategory.create({ name: CategoryName });
  res.redirect('/categories');
};

const EditCategoryView = async (req, res) => {
  try {
    const { id } = req.params;
    const category = await ProductCategory.findByPk(id, { raw: true });

    if (!category) {
      return res.status(404).send('Category not found');
    }

    res.render('categories/EdiCategory', { category });
  } catch (error) {
    console.error('Error fetching service:', error);
    res.status(500).send('Internal Server Error');
  }
};

const EditCategory = async (req, res) => {
  const { id } = req.params;

  const CategoryName = req.body.CategoryName;

  // Update the service in the database
  await ProductCategory.update({ name: CategoryName }, { where: { id } });

  // Redirect to the services page
  res.redirect('/categories');
};

const DeleteCategory = async (req, res) => {
  const { id } = req.params;
  await ProductCategory.destroy({ where: { id } });
  res.redirect('/categories');
};

module.exports = { GetAllCategories, AddCategoryView, AddCategory, EditCategoryView, EditCategory, DeleteCategory };
