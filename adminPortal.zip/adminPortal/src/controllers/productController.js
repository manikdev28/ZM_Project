const { Products, ProductCategory } = require('../models');
const ImageKit = require('imagekit');

// SDK initialization
var imagekit = new ImageKit({
  publicKey: "public_5J27hETdJ/Qqdmt102EjAbUOOd4=",
  privateKey: "private_rI5739WSAbOayuMXnydJW74H40k=",
  urlEndpoint: "https://ik.imagekit.io/rw05vsmbv"
});

const GetAllServices = async (req, res) => {
  const services = await Products.findAll({ raw: true });
  res.render('services/Services', { Allservices: services });
};

const AddServiceView = async (req, res) => {
  const ProductCategories = await ProductCategory.findAll({ raw: true })
  res.render('services/AddService', { ProductCategories });
};

const AddService = async (req, res) => {

  const {
    ProductName,
    categories,
    productDetails,
    mainDescription,
    Firsttitle,
    Firstdescription,
    Secondtitle,
    Seconddescription,
    WhyChoosetitle,
    WhyChoosedescription,
    SelectingTheRighttitle,
    SelectingTheRightdescription,
    keyFeatureTitle,
    KeyFeaturePoint1Title,
    KeyFeaturePoint1Description,
    KeyFeaturePoint2Title,
    KeyFeaturePoint2Description,
    KeyFeaturePoint3Title,
    KeyFeaturePoint3Description,
    KeyFeaturePoint4Title,
    KeyFeaturePoint4Description,
    WhyChoosePoint1Title,
    WhyChoosePoint1Description,
    WhyChoosePoint2Title,
    WhyChoosePoint2Description,
    WhyChoosePoint3Title,
    WhyChoosePoint3Description,
    WhyChoosePoint4Title,
    WhyChoosePoint4Description,
    SelectingTheRightPoint1Title,
    SelectingTheRightPoint1Description,
    SelectingTheRightPoint2Title,
    SelectingTheRightPoint2Description,
    SelectingTheRightPoint3Title,
    SelectingTheRightPoint3Description,
    SelectingTheRightPoint4Title,
    SelectingTheRightPoint4Description,
    conclusion1,
    conclusion2,
    metaTitle, metaDescription, metaKeywords, keywordsPlanner, canonical, robots,
    route
  } = req.body;

  const fileUploadPromises = {};

  // Define the expected fields
  const expectedFields = [
    'ProductImage',
  ];

  // Iterate over the expected fields to find and upload the files
  for (const field of expectedFields) {
    const uploadedFile = req.files.find(file => file.fieldname === field);

    if (!uploadedFile) {
      return res.status(400).json({ error: `${field} not provided` });
    }

    // Upload to ImageKit
    fileUploadPromises[field] = imagekit.upload({
      file: uploadedFile.buffer,
      fileName: uploadedFile.originalname,
    });
  }

  // Wait for all uploads to complete
  const uploadedFiles = await Promise.all(Object.values(fileUploadPromises));

  // Store the image URLs returned by ImageKit
  const [
    productImageUrl,
  ] = uploadedFiles.map(file => file.url);

  let FormattedproductDescription = {
    description: mainDescription,
    blog: {
      title: Firsttitle,
      description: Firstdescription,
      sections: [
        {
          heading: Secondtitle,
          content: Seconddescription
        },
        {
          heading: keyFeatureTitle,
          features: [
            {
              title: KeyFeaturePoint1Title,
              description: KeyFeaturePoint1Description
            },
            {
              title: KeyFeaturePoint2Title,
              description: KeyFeaturePoint2Description
            },
            {
              title: KeyFeaturePoint3Title,
              description: KeyFeaturePoint3Description
            },
            {
              title: KeyFeaturePoint4Title,
              description: KeyFeaturePoint4Description
            }
          ]
        },
        {
          heading: WhyChoosetitle,
          content: WhyChoosedescription,
          tips: [
            {
              title: WhyChoosePoint1Title,
              description: WhyChoosePoint1Description
            },
            {
              title: WhyChoosePoint2Title,
              description: WhyChoosePoint2Description
            },
            {
              title: WhyChoosePoint3Title,
              description: WhyChoosePoint3Description
            },
            {
              title: WhyChoosePoint4Title,
              description: WhyChoosePoint4Description
            }
          ]
        },
        {
          heading: SelectingTheRighttitle,
          content: SelectingTheRightdescription,
          tips: [
            {
              title: SelectingTheRightPoint1Title,
              description: SelectingTheRightPoint1Description
            },
            {
              title: SelectingTheRightPoint2Title,
              description: SelectingTheRightPoint2Description
            },
            {
              title: SelectingTheRightPoint3Title,
              description: SelectingTheRightPoint3Description
            },
            {
              title: SelectingTheRightPoint4Title,
              description: SelectingTheRightPoint4Description
            }
          ]
        },
        {
          heading: "Conclusion",
          content: conclusion1,
          content2: conclusion2
        }
      ]
    }
  }

  // Trim whitespace for each keyword in the array (optional but recommended)
  const serviceData = {
    status: 1,
    code: `${Math.random().toString(36).substring(2, 7)}-${Date.now().toString().slice(-5)}`,
    categoryId: categories,
    name: ProductName,
    description: FormattedproductDescription,
    image: productImageUrl,
    productDetails: JSON.parse(productDetails),
    seo: {
      metaTitle,
      metaDescription,
      metaKeywords,
      keywordsPlanner,
      canonical,
      robots
    },
    route
  };

  // console.log(serviceData, 'check added product')

  await Products.create(serviceData);
  res.redirect('/products');
};

const EditServiceView = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Products.findByPk(id, { raw: true });
    const ProductCategories = await ProductCategory.findAll({ raw: true })

    if (!product) {
      return res.status(404).send('Product not found');
    }

    // product.seo = JSON.parse(product.seo);
    product.description = JSON.parse(product.description);
    product.productDetails = JSON.parse(product.productDetails);
    product.seo = JSON.parse(product.seo);

    // console.log(product.description, 'Editing View')
    // console.log(product.description.blog, 'Editing View Blog')
    // console.log(product, 'Editing View Blog')
    // if(  )


    res.render('services/EditService', { product, ProductCategories });
  } catch (error) {
    console.error('Error fetching service:', error);
    res.status(500).send('Internal Server Error');
  }
};

const EditService = async (req, res) => {
  const { id } = req.params;

  const {
    ProductName,
    categories,
    productDetails,
    mainDescription,
    Firsttitle,
    Firstdescription,
    Secondtitle,
    Seconddescription,
    WhyChoosetitle,
    WhyChoosedescription,
    SelectingTheRighttitle,
    SelectingTheRightdescription,
    keyFeatureTitle,
    KeyFeaturePoint1Title,
    KeyFeaturePoint1Description,
    KeyFeaturePoint2Title,
    KeyFeaturePoint2Description,
    KeyFeaturePoint3Title,
    KeyFeaturePoint3Description,
    KeyFeaturePoint4Title,
    KeyFeaturePoint4Description,
    WhyChoosePoint1Title,
    WhyChoosePoint1Description,
    WhyChoosePoint2Title,
    WhyChoosePoint2Description,
    WhyChoosePoint3Title,
    WhyChoosePoint3Description,
    WhyChoosePoint4Title,
    WhyChoosePoint4Description,
    SelectingTheRightPoint1Title,
    SelectingTheRightPoint1Description,
    SelectingTheRightPoint2Title,
    SelectingTheRightPoint2Description,
    SelectingTheRightPoint3Title,
    SelectingTheRightPoint3Description,
    SelectingTheRightPoint4Title,
    SelectingTheRightPoint4Description,
    conclusion1,
    conclusion2,
    metaTitle, metaDescription, metaKeywords, keywordsPlanner, canonical, robots,
    route
  } = req.body;

  let flattenedProductDetails = {};

  if (productDetails && typeof productDetails === 'object') {
    // Loop through each key in the productDetails object
    for (let key in productDetails) {
      // Check if the key exists in the productDetails object (works for objects with null prototype)
      if (Object.prototype.hasOwnProperty.call(productDetails, key)) {
        const productDetail = productDetails[key];

        // Check if both 'key' and 'value' are arrays (for #{key} object)
        if (Array.isArray(productDetail.key) && Array.isArray(productDetail.value)) {
          // Ensure that keys and values arrays are of equal length
          if (productDetail.key.length === productDetail.value.length) {
            for (let i = 0; i < productDetail.key.length; i++) {
              const currentKey = productDetail.key[i].trim();
              const currentValue = productDetail.value[i].trim();

              // Only add non-empty key-value pairs
              if (currentKey && currentValue) {
                flattenedProductDetails[currentKey] = currentValue;
              }
            }
          }
        } else if (productDetail.key && productDetail.value) {
          // If key and value are not arrays, add them as a single key-value pair
          const currentKey = productDetail.key.trim();
          const currentValue = productDetail.value.trim();

          if (currentKey && currentValue) {
            flattenedProductDetails[currentKey] = currentValue;
          }
        }
      }
    }
  }

  // Initialize variables for image URLs
  let productImageUrl;

  // Fetch existing service from database
  const existingService = await Products.findOne({ where: { id } });

  // Check and handle image uploads
  const uploadImage = async (file) => {
    const uploadResult = await imagekit.upload({
      file: file.buffer,
      fileName: file.originalname,
    });
    return uploadResult.url;
  };

  const handleImageUpload = async (field, existingUrl) => {
    const uploadedFiles = req.files.filter(file => file.fieldname === field);  // Get all files for the field

    // If files were uploaded for this field, upload the first one and return its URL
    if (uploadedFiles.length > 0) {
      return await uploadImage(uploadedFiles[0]);  // Upload the first file
    } else {
      return existingUrl;  // Use existing image URL
    }
  };

  // Handle all image fields
  productImageUrl = await handleImageUpload('productImage', existingService.image);

  let FormattedproductDescription = {
    description: mainDescription,
    blog: {
      title: Firsttitle,
      description: Firstdescription,
      sections: [
        {
          heading: Secondtitle,
          content: Seconddescription
        },
        {
          heading: keyFeatureTitle,
          features: [
            {
              title: KeyFeaturePoint1Title,
              description: KeyFeaturePoint1Description
            },
            {
              title: KeyFeaturePoint2Title,
              description: KeyFeaturePoint2Description
            },
            {
              title: KeyFeaturePoint3Title,
              description: KeyFeaturePoint3Description
            },
            {
              title: KeyFeaturePoint4Title,
              description: KeyFeaturePoint4Description
            }
          ]
        },
        {
          heading: WhyChoosetitle,
          content: WhyChoosedescription,
          tips: [
            {
              title: WhyChoosePoint1Title,
              description: WhyChoosePoint1Description
            },
            {
              title: WhyChoosePoint2Title,
              description: WhyChoosePoint2Description
            },
            {
              title: WhyChoosePoint3Title,
              description: WhyChoosePoint3Description
            },
            {
              title: WhyChoosePoint4Title,
              description: WhyChoosePoint4Description
            }
          ]
        },
        {
          heading: SelectingTheRighttitle,
          content: SelectingTheRightdescription,
          tips: [
            {
              title: SelectingTheRightPoint1Title,
              description: SelectingTheRightPoint1Description
            },
            {
              title: SelectingTheRightPoint2Title,
              description: SelectingTheRightPoint2Description
            },
            {
              title: SelectingTheRightPoint3Title,
              description: SelectingTheRightPoint3Description
            },
            {
              title: SelectingTheRightPoint4Title,
              description: SelectingTheRightPoint4Description
            }
          ]
        },
        {
          heading: "Conclusion",
          content: conclusion1,
          content2: conclusion2
        }
      ]
    }
  }

  // Prepare the service data for update
  const serviceData = {
    categoryId: categories,
    name: ProductName,
    description: FormattedproductDescription,
    image: productImageUrl,
    productDetails: flattenedProductDetails,
    seo: {
      metaTitle,
      metaDescription,
      metaKeywords,
      keywordsPlanner,
      canonical,
      robots
    },
    route
  };

  console.log(serviceData, "updated service")

  // Update the service in the database
  await Products.update(serviceData, { where: { id } });

  // Redirect to the services page
  res.redirect('/products');
};

const ChangeStatusService = async (req, res) => {
  try {
    const ProductId = req.params.id
    const product = await Products.findOne({
      where: {
        id: ProductId
      },
      attributes: ['status']
    });

    await Products.update(
      { status: product.status === 1 ? 0 : 1 },
      { where: { id: ProductId } }
    );

    res.redirect('/products');
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const DeleteService = async (req, res) => {
  const { id } = req.params;
  await Products.destroy({ where: { id } });
  res.redirect('/products');
};

module.exports = { GetAllServices, AddServiceView, AddService, EditServiceView, EditService, DeleteService, ChangeStatusService };
